
1. Do not change below file
	+ Encrypt_Tool_v0p5.jar
	+ keys.txt
	+ README.txt

2. Just change file raw_data.txt --> change value after MACHINE_CODE and COMPANY_CODE. Close this file after complete editing 
	Example:
		COMPANY_CODE = DNP
		MACHINE_CODE = VM-6


3. Run Encrypt_Tool_v0p5.jar

4. The tool will create folder logs (not important) and file encrypted_data.txt

5. Open file encrypted_data.txt to get encrypted data. For example
	COMPANY_CODE = X6EtcuSbxZ5W0yRxEpjn3Q==
	MACHINE_CODE = 9K1OYnAESRs2iZyoUTt2Mg==

