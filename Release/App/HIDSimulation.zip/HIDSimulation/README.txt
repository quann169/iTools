

---- Copyright � 2018 by Jimmy Quan ----

1. Install environment
	+ Windows 7 - 10
	+ Java 32 bits 
	+ Copy hidapi.dll Java bin folder (C:\Program Files (x86)\Java\jre1.8.0_172\bin)

2. Run HIDSimulation.jar first time to get productID and vendorID

3. Update HIDCfg.txt

4. Rerun HIDSimulation.jar ==> check the LED to see program and board is connected or not